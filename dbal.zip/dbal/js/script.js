var authorsTbl = '';

//$(function() {
$(document).ready(function(){

    // draw function [called if the database updates]
    function draw_data() {
        if ($.fn.dataTable.isDataTable('#authors-tbl') && authorsTbl != '') {
            authorsTbl.draw(true)
        } else {
            load_data();
        }
    }

    function load_data() {
        authorsTbl = $('#authors-tbl').DataTable({
            dom: '<"row"B>flr<"py-2 my-2"t>ip',
            "processing": true,
            "serverSide": true,
            "ajax": {
                url: "./get_patient.php",
                method: 'POST'
            },
            columns: [{
                    data: 'name',
                    className: 'py-0 px-1'
                },
                {
                    data: 'age',
                    className: 'py-0 px-1'
                },
                {
                    data: 'city',
                    className: 'py-0 px-1'
                },
                {
                    data: 'state',
                    className: 'py-0 px-1'
                },
                {
                    data: 'country',
                    className: 'py-0 px-1'
                },
                {
                    data: 'dob',
                    className: 'py-0 px-1'
                },
                {
                    data: 'blood_group',
                    className: 'py-0 px-1'
                },
                {
                    data: null,
                    orderable: false,
                    className: 'text-center py-0 px-1',
                    render: function(data, type, row, meta) {
                        console.log()
                        return '<a class="me-2 btn btn-sm rounded-0 py-0 edit_data btn-primary" href="javascript:void(0)"  onclick="editpatient(' + (row.id) + ')">Edit</a><a class="me-2 btn btn-sm rounded-0 py-0 edit_data btn-danger" href="javascript:void(0)"  onclick="deletepatient(' + (row.id) + ')">Delete</a>';
                    }
                }
            ],
            buttons: [{
                text: "Add Patient",
                className: "btn btn-primary py-0",
                action: function(e, dt, node, config) {
                    $('#savepatient').find("input,select").val('').end();
                    $('#addpatient').val('Save');
                    $('#add_modal').modal('show')
                     getcountry();
                }
            }],
            "order": [
                [1, "asc"]
            ],
            initComplete: function(settings) {
                $('.paginate_button').addClass('p-1')
            }
        });
    }

    //Load Data
    load_data();


    //Saving new Data
    $('#savepatient').submit(function(e) {
       
            e.preventDefault()
            $('#add_modal button').attr('disabled', true)
            $('#add_modal button[form="savepatient"]').text("saving ...")
            $.ajax({
                url: 'save_data.php',
                data: $(this).serialize(),
                method: 'POST',
                dataType: "json",
                error: err => {
                    alert("An error occured. Please chech the source code and try again")
                },
                success: function(resp) {
                  
                    if (!!resp.status) {
                        if (resp.status == 'success') {
                            var _el = $('<div>')
                            _el.hide()
                            _el.addClass('alert alert-primary alert_msg')
                            _el.text("Data successfully saved");
                            $('#savepatient').get(0).reset()
                            $('.modal').modal('hide')
                            $('#msg').append(_el)
                            _el.show('slow')
                            draw_data();
                            setTimeout(() => {
                                _el.hide('slow')
                                    .remove()
                            }, 2500)
                        } else if (resp.status == 'success' && !!resp.msg) {
                            var _el = $('<div>')
                            _el.hide()
                            _el.addClass('alert alert-danger alert_msg form-group')
                            _el.text(resp.msg);
                            $('#savepatient').append(_el)
                            _el.show('slow')
                        } else {
                            alert("An error occured. Please chech the source code and try again")
                        }
                    } else {
                        alert("An error occured. Please chech the source code and try again")
                    }

                    $('#add_modal button').attr('disabled', false)
                    $('#add_modal button[form="savepatient"]').text("Save")
                }
            })
    })

    //==Update record   
    $('#editpatient').submit(function(e) {
            e.preventDefault()
            // $('#edit_modal button').attr('disabled', true)
            // $('#edit_modal button[form="edit-author-frm"]').text("saving ...")
            $.ajax({
                url: 'save_data.php',
                data: $(this).serialize(),
                method: 'POST',
                dataType: "json",
                error: err => {
                    alert("An error occured. Please chech the source code and try again")
                },
                success: function(resp) {
                     
                    if (!!resp.status) {
                        if (resp.status == 'success') {
                            var _el = $('<div>')
                            _el.hide()
                            _el.addClass('alert alert-primary alert_msg')
                            _el.text("Data successfully updated");
                           $('.modal').modal('hide')
                            $('#msg').append(_el)
                            _el.show('slow')
                            draw_data();
                            setTimeout(() => {
                                _el.hide('slow')
                                    .remove()
                            }, 2500)
                        } else if (resp.status == 'success' && !!resp.msg) {
                            var _el = $('<div>')
                            _el.hide()
                            _el.addClass('alert alert-danger alert_msg form-group')
                            _el.text(resp.msg);
                            $('#editpatient').append(_el)
                            _el.show('slow')
                        } else {
                            alert("An error occured. Please chech the source code and try again")
                        }
                    } else {
                        alert("An error occured. Please chech the source code and try again")
                    }

                    $('#edit_modal button').attr('disabled', false)
                    $('#edit_modal button[form="editpatient"]').text("Save")
                }
            })
    })

    //===Age from date of birth
    $('#dob').change(function(){
           
            var datestring=$('#dob').val();                  
            dob = new Date(datestring);
            var today = new Date();
            var age = Math.floor((today-dob) / (365.25 * 24 * 60 * 60 * 1000));
            $('#age').val(age);
    });

   //==Get country
        function getcountry(){

                    $.ajax({
                        url: 'get_master_data.php',
                        data: { searchtype: 'country' },
                        method: 'POST',
                        dataType: 'json',
                        error: err => {
                            alert("An error occured while fetching single data")
                        },
                        success: function(resp) {
                               $('#country').append('<option value="">Select country</option>');
                           jQuery(resp.data).each(function(i, item){
                            $('#country').append('<option value="'+item.name+'">'+item.name+'</option>');
                            })
                        }
                    })
                
        }

       


        $('.country').change(function(){
          
            var country=$(this).val(); 
              
             $.ajax({
                        url: 'get_master_data.php',
                        data: { "searchtype": "state","countryname" : country },
                        method: 'POST',
                        dataType: 'json',
                        error: err => {
                            alert("An error occured while fetching single data")
                        },
                        success: function(resp) {
                             $('.state').html('');

                               $('.state').append('<option value="">Select State</option>');
                           jQuery(resp.data).each(function(i, item){
                            $('.state').append('<option value="'+item.name+'">'+item.name+'</option>');
                            })
                        }
                    })                 
           

        });


         $('.state').change(function(){
           
            var state=$(this).val(); 
             
                    $.ajax({
                        url: 'get_master_data.php',
                        data: { "searchtype": "city","statename" : state },
                        method: 'POST',
                        dataType: 'json',
                        error: err => {
                            alert("An error occured while fetching single data")
                        },
                        success: function(resp) {
                             $('.city').html('');
                               $('.city').append('<option value="">Select City</option>');
                           jQuery(resp.data).each(function(i, item){
                            $('.city').append('<option value="'+item.name+'">'+item.name+'</option>');
                            })
                        }
                    })                 
           

        });


    // DELETE Data
    $('#delete-author-frm').submit(function(e) {
        e.preventDefault()
        $('#delete_modal button').attr('disabled', true)
        $('#delete_modal button[form="delete-author-frm"]').text("deleting data ...")
         var id=$('#delete_modal').find('input[name="id"]').val();
        $.ajax({
            url: 'save_data.php',
            data: {'id':id ,'reqtype':'delete'},
            method: 'POST',
            dataType: "json",
            error: err => {
                alert("An error occured. Please chech the source code and try again")
            },
            success: function(resp) {
                if (!!resp.status) {
                    if (resp.status == 'success') {
                        var _el = $('<div>')
                        _el.hide()
                        _el.addClass('alert alert-primary alert_msg')
                        _el.text("Data successfully Deleted");
                        $('#delete-author-frm').get(0).reset()
                        $('.modal').modal('hide')
                        $('#msg').append(_el)
                        _el.show('slow')
                        draw_data();
                        setTimeout(() => {
                            _el.hide('slow')
                                .remove()
                        }, 2500)
                    } else if (resp.status == 'success' && !!resp.msg) {
                        var _el = $('<div>')
                        _el.hide()
                        _el.addClass('alert alert-danger alert_msg form-group')
                        _el.text(resp.msg);
                        $('#delete-author-frm').append(_el)
                        _el.show('slow')
                    } else {
                        alert("An error occured. Please chech the source code and try again")
                    }
                } else {
                    alert("An error occured. Please chech the source code and try again")
                }

                $('#delete_modal button').attr('disabled', false)
                $('#delete_modal button[form="delete-author-frm"]').text("YEs")
            }
        })
    })


    //========Validation=========
    $("#dob").keydown(function (event) { event.preventDefault(); });

    $('#name').on('keypress', function (event) {
    var regex = new RegExp("/^[a-zA-Z]+$/");
    var name=$('#name').val();
    var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
    if (!regex.test(key) && name.length > 45) {
       event.preventDefault();
       return false;
    }
    });
  
});


  



   //==Get single patient data 
   function editpatient(id){

                    $.ajax({
                        url: 'save_data.php',
                        data: { 'id':id ,'reqtype':'edit'},
                        method: 'POST',
                        dataType: 'json',
                        error: err => {
                            alert("An error occured while fetching single data")
                        },
                        success: function(resp) {
                            if (!!resp.status) {
                                $('#editpatient').find("input,select").val('').end();
                                $('#updatepatient').val('Save');
                                jQuery(resp.data).each(function(i, item){
                                    $('#nameu').val(item.name);                                   
                                    //$('.dobclass').val(item.dob);
                                    $('input[id=dobu]').val(item.dob);
                                    $('input[name=id]').val(item.id);
                                    $('#ageu').val(item.age);
                                    $('#bloodgroupu').val(item.blood_group);


                                       //==country== 
                                       $.ajax({
                                          url: 'get_master_data.php',
                                          data: { searchtype: 'country' },
                                           method: 'POST',
                                          dataType: 'json',
                                          error: err => {
                                            alert("An error occured while fetching single data")
                                          },
                                         success: function(resp) {
                                            $('#countryu').html('');
                                           $('#countryu').append('<option value="">Select country</option>');
                                             jQuery(resp.data).each(function(i, countrydata){
                                              var seltype='';
                                              if(countrydata.name == item.country){seltype='selected="selected"';}
                                             $('#countryu').append('<option value="'+countrydata.name+'" '+seltype+'>'+countrydata.name+'</option>');
                                           })
                                          }
                                        })

                                        //===state
                                            $.ajax({
                                            url: 'get_master_data.php',
                                            data: { "searchtype": "state","countryname" : item.country },
                                            method: 'POST',
                                            dataType: 'json',
                                           error: err => {
                                            alert("An error occured while fetching single data")
                                             },
                                            success: function(resp) {
                                                  $('#stateu').html('');
                                              $('#stateu').append('<option value="">Select State</option>');
                                             jQuery(resp.data).each(function(i, stateitem){
                                           var seltype='';
                                          if(stateitem.name == item.state){seltype='selected="selected"';}
                                            $('#stateu').append('<option value="'+stateitem.name+'" '+seltype+'>'+stateitem.name+'</option>');
                                           })
                                        //===city
                                          }
                                        }) 

                                        //===city
                                        $.ajax({
                                          url: 'get_master_data.php',
                                          data: { "searchtype": "city","statename" : item.state },
                                          method: 'POST',
                                          dataType: 'json',
                                          error: err => {
                                           alert("An error occured while fetching single data")
                                          },
                                          success: function(resp) {
                                              $('#cityu').html('');
                                          $('#cityu').append('<option value="">Select City</option>');
                                          jQuery(resp.data).each(function(i, cityitem){
                                            var seltype='';
                                          if(cityitem.name == item.city){seltype='selected="selected"';}
                                              $('#cityu').append('<option value="'+cityitem.name+'" '+seltype+'>'+cityitem.name+'</option>');
                                          })
                        }
                    })                

                                   
                                })//each jquery
                               
                                $('#edit_modal').modal('show')
                            } else {
                                alert("An error occured while fetching single data")
                            }
                        }
                    })
                
   }

   //===Delete record
   function deletepatient(id){
    $('#delete_modal').find('input[name="id"]').val(id)
    $('#delete_modal').modal('show')      
   }






   