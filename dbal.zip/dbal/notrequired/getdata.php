<?php
include "vendor/autoload.php";
include "db.php";

$sql = "SELECT * FROM product_info";
$stmt = $conn->query($sql); // Simple, but has several drawbacks

while (($row = $stmt->fetchAssociative()) !== false) {
    echo $row['sku'].'<BR />';
}

?>