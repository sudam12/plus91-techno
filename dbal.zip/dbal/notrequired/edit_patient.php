<?php
require_once('db.php');
extract($_POST);




$query="SELECT `id`,`name`, `age`, `city`, `state`, `country`, `dob`, `blood_group` FROM `tbl_patient` where id='{$id}'";
$stmt = $conn->prepare($query);
$resultSet = $stmt->executeQuery();

$data = array();

while($row =  $resultSet->fetchAssociative()){
    $row['dob'] = date("Y-m-d",strtotime($row['dob']));
    $date = new DateTime($row['dob']);
    $now = new DateTime();
    $interval = $now->diff($date);
    $row['age']= $interval->y;
    $data[] = $row;
}

// $query = $conn->query("SELECT * FROM `tbl_patient` where id = '{$id}'");
if($resultSet){
    $resp['status'] = 'success';
    $resp['data'] = $data;
}else{
    $resp['status'] = 'success';
    $resp['error'] = 'Somthing went wrong ';
}
echo json_encode($resp);